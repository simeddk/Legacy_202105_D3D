#include "Framework.h"
#include "Billboard.h"

Billboard::Billboard(Shader* shader)
	: Renderer(shader)
{
	diffuseMap = new Texture(L"Terrain/grass_05.tga");
	sDiffuseMap = shader->AsSRV("DiffuseMap");
}

Billboard::~Billboard()
{
	SafeDelete(diffuseMap);
}

void Billboard::Render()
{
	if (vertices.size() != vertexCount)
	{
		vertexCount = vertices.size();

		SafeDelete(vertexBuffer);
		vertexBuffer = new VertexBuffer(&vertices[0], vertices.size(), sizeof(VertexBillboard));

	}

	Super::Render();

	sDiffuseMap->SetResource(diffuseMap->SRV());

	shader->Draw(0, Pass(), vertexCount);
}

void Billboard::Add(Vector3 & position, Vector2 & scale)
{
	vertices.push_back({position, scale});

	
}
