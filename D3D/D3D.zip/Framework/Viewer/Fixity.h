#pragma once

class Fixity : public Camera
{
public:
	Fixity();
	~Fixity();

	void Update();
};