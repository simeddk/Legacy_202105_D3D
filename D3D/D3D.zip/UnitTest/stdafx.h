#pragma once

//#define no_init_all deprecated

#include "Framework.h"
#pragma comment(lib, "../Debug/Framework.lib")