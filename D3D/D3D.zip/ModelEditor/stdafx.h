#pragma once

//#define no_init_all deprecated

#include "Framework.h"
#pragma comment(lib, "../Debug/Framework.lib")

#include "Assimp/Importer.hpp"
#include "Assimp/postprocess.h"
#include "Assimp/scene.h"
#pragma comment(lib, "Assimp/assimp-vc140-mt.lib")